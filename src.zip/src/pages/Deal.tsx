import React from 'react'
import DealPageTite from '../components/deal/DealPageTitle'
import DealsFilterAndProducts from '../components/deal/DealsFilterAndProducts'

const Deal = () => {
  return (
 <>
 <DealPageTite />
 <DealsFilterAndProducts />
 </>
  )
}

export default Deal
