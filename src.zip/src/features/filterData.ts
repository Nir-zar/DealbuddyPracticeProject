import { createSlice } from "@reduxjs/toolkit";

const initialState = { 
  shortBy: "date",
  pageNumber : 1, 
  productType : "all"
};

const filterDataSlice = createSlice({
  name: "filterData",
  initialState,
  reducers: {
    filterData: (state, action) => {
      // eslint-disable-next-line no-self-assign
      state.shortBy = action.payload.shortBy;
      state.pageNumber = action.payload.pageNumber;
      console.log(action.payload);
    },

    filterDataByCategory : (state, action) => {
      // eslint-disable-next-line no-self-assign
      state.productType = action.payload;
    }
  },
});

export const { filterData, filterDataByCategory } = filterDataSlice.actions;

export default filterDataSlice.reducer;
