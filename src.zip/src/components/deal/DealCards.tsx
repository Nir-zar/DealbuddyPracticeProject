import { Box, Button } from "@mui/material";
import React, { useEffect, useState } from "react";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Typography from "@mui/material/Typography";
import CommonCard from "../common components/CommonCard";
import { getData } from "../../api/homeApi";
import CommonCoupon from "../common components/CommonCoupon";
import CircularProgress from "@mui/material/CircularProgress";
import { useDispatch, useSelector } from "react-redux";
import { Height } from "@mui/icons-material";
import theme from "../../theme";
import { filterData } from "../../features/filterData";
import { filterDataByCategory } from "../../features/filterData";

interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

// function CustomTabPanel(props: TabPanelProps) {
//   const { children, value, index, ...other } = props;

//   return (
//     <div
//       role="tabpanel"
//       hidden={value !== index}
//       id={`simple-tabpanel-${index}`}
//       aria-labelledby={`simple-tab-${index}`}
//       {...other}
//     ></div>
//   );
// }

function a11yProps(index: string) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
  };
}

const DealCards = () => {
  const [value, setValue] = React.useState("  ");
  const [salesCardData, setSalesCardData] = useState([]);
  const [dataStats, setDataStats] = useState({ all: "", sale: "", coupon: "" });
  const [currentCard, setCurrentCard] = useState("all");
  const [loading, setLoading] = useState(true);
  const [shortBy, setShortBy] = useState("date");
  const [productType, setProductType] = useState("");
  // const [pageNumber, setPageNumber] = useState(1)

  // const data = useSelector((store)=>{
  //   const newData = store.filterData.shortBy;
  //   setShortBy(newData)
  // });

  const valueNew = useSelector((store) => store.filterData.shortBy);
  let pageNumber = useSelector((store) => store.filterData.pageNumber);
  console.log(useSelector((store) => store.filterData.shortBy));

  const productCategory = useSelector((store) => store.filterData.productType);

  const url = `deal/deals?v=1705657100045&&limit=36&updateViewCount=true&t=1705657100045`;
  const dispatch = useDispatch();

  useEffect(() => {
    const paramsForAll = {
      shortBy: valueNew,
      page: pageNumber,
    };

    const paramsForSaleAndCoupon = {
      shortBy: valueNew,
      productType: productCategory,
      page: pageNumber,
    };

    if (pageNumber == 1) {
      setLoading(true);
      getData(
        url,
        productCategory == "all" ? paramsForAll : paramsForSaleAndCoupon
      ).then((res) => {
        setSalesCardData(res.data.items);
        setDataStats({
          ...dataStats,
          all: res.data.total,
          sale: res.data.sellCount,
          coupon: res.data.couponCount,
        });
        setLoading(false);
      });
    } else {
      getData(
        url,
        productCategory == "all" ? paramsForAll : paramsForSaleAndCoupon
      ).then((res) => {
        const newPageData = res.data.items;
        setSalesCardData(salesCardData.concat(newPageData));
        console.log(salesCardData);
        console.log(salesCardData.concat(newPageData));
        setDataStats({
          ...dataStats,
          all: res.data.total,
          sale: res.data.sellCount,
          coupon: res.data.couponCount,
        });
        setLoading(false);
      });
    }
  }, [valueNew, pageNumber, productCategory]);

  const handleChange = (event: React.SyntheticEvent, newValue: string) => {
    alert(newValue + pageNumber);
    setLoading(true);
    dispatch(filterDataByCategory(newValue));
    const paramsForAll = {
      shortBy: valueNew,
      page: pageNumber,
    };

    const paramsForSaleAndCoupon = {
      shortBy: valueNew,
      productType: newValue,
      page: pageNumber,
    };

    console.log(paramsForSaleAndCoupon);

    if (pageNumber > 1) {
      dispatch(filterData({ shortBy: valueNew, pageNumber: 1 }));
    }

    // getData(
    //   url,
    //   newValue == "all" ? paramsForAll : paramsForSaleAndCoupon
    // ).then((res) => {
    //   setSalesCardData(res.data.items);
    //   console.log(res.data);

    //   setDataStats({
    //     ...dataStats,

    //     sale: res.data.sellCount,
    //     coupon: res.data.couponCount,
    //   });
    //   setLoading(false);
    // });
  };

  return (
    <Box
      component={"div"}
      sx={{
        height: "62.5rem",
        width: "980px",
        display: "flex",
        flexDirection: "column",
        overflowY: "scoll",
      }}
    >
      <Box sx={{ width: "100%" }}>
        <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
          <Tabs
            value={value}
            onChange={handleChange}
            aria-label="basic tabs example"
          >
            <Tab
              onClick={() => setCurrentCard("all")}
              value={"all"}
              label={`all ${dataStats.all}`}
              {...a11yProps("all")}
            />
            <Tab
              onClick={() => {
                setCurrentCard("sale"), setProductType("sale");
              }}
              value={"sale"}
              label={`Sale ${dataStats.sale}`}
              {...a11yProps("sale")}
            />
            <Tab
              onClick={() => {
                setCurrentCard("coupon"), setProductType("coupon");
              }}
              value={"coupon"}
              label={`Coupon ${dataStats.coupon}`}
              {...a11yProps("coupon")}
            />
          </Tabs>
        </Box>
        {/* <CustomTabPanel  value={value} index={0}>
          All {dataStats.all && `(${dataStats.all})`}
        </CustomTabPanel>
        <CustomTabPanel value={value} index={1}>
          Sale {dataStats.sale && `(${dataStats.sale})`}
        </CustomTabPanel>
        <CustomTabPanel value={value} index={2}>
          Coupon {dataStats.coupon && `(${dataStats.coupon})`}
        </CustomTabPanel> */}
      </Box>

      <Box
        component={"div"}
        sx={{
          height: "55rem",
          width: "100%",
          display: "flex",
          flexWrap: "wrap",
          overflowY: "scroll",
        }}
      >
        {loading ? (
          <Box
            sx={{
              mt: "10rem",
              width: "100%",
              height: "100%",
              display: "flex",
              alignItems: "center",
              flexDirection: "column",
            }}
          >
            <CircularProgress />
            <Typography sx={{ mt: "1rem" }}>Loading......</Typography>
          </Box>
        ) : (
          <>
            {currentCard == "all" &&
              salesCardData.map(
                ({
                  category,
                  imageUrl,
                  clicks,
                  productImages,
                  productType,
                  productModes,
                  stores,
                  name,
                  NZWide,
                  locations,
                  couponCode,
                  index,
                }) => {
                  return (
                    <>
                      {couponCode == null ? (
                        <CommonCard
                          key={index}
                          category={category}
                          imageUrl={imageUrl}
                          clicks={clicks}
                          productImages={productImages}
                          productType={productType}
                          productModes={productModes}
                          stores={stores}
                          name={name}
                          NZWide={NZWide}
                          locations={locations}
                          width={4}
                        />
                      ) : (
                        <CommonCoupon
                          category={category}
                          imageUrl={imageUrl}
                          clicks={clicks}
                          productImages={productImages}
                          productType={productType}
                          productModes={productModes}
                          stores={stores}
                          name={name}
                          NZWide={NZWide}
                          locations={locations}
                          width={4}
                        />
                      )}
                    </>
                  );
                }
              )}
          </>
        )}

        {currentCard == "sale" &&
          salesCardData.map(
            ({
              category,
              imageUrl,
              clicks,
              productImages,
              productType,
              productModes,
              stores,
              name,
              NZWide,
              locations,
              index,
            }) => {
              return (
                <CommonCard
                  key={index}
                  category={category}
                  imageUrl={imageUrl}
                  clicks={clicks}
                  productImages={productImages}
                  productType={productType}
                  productModes={productModes}
                  stores={stores}
                  name={name}
                  NZWide={NZWide}
                  locations={locations}
                  width={4}
                />
              );
            }
          )}

        {currentCard == "coupon" &&
          salesCardData.map(
            ({
              category,
              imageUrl,
              clicks,
              productImages,
              productType,
              productModes,
              stores,
              name,
              NZWide,
              locations,
              index,
            }) => {
              return (
                <CommonCoupon
                  key={index}
                  category={category}
                  imageUrl={imageUrl}
                  clicks={clicks}
                  productImages={productImages}
                  productType={productType}
                  productModes={productModes}
                  stores={stores}
                  name={name}
                  NZWide={NZWide}
                  locations={locations}
                  width={4}
                />
              );
            }
          )}
      </Box>

      <Button
        onClick={() =>
          dispatch(filterData({ shortBy: valueNew, pageNumber: pageNumber++ }))
        }
        sx={{
          height: "2.5rem",
          width: "8rem",
          alignSelf: "center",
          background: theme.gradient_color.button_color,
          mt: "1rem",
          color: theme.palette.common.white,
          fontSize: theme.typography.subtitle2.xl,
          "&:hover": {
            background: theme.gradient_color.button_hover_color,
            color: theme.palette.common.black,
          },
        }}
      >
        <Typography>Load More</Typography>
      </Button>
    </Box>
  );
};

export default DealCards;
