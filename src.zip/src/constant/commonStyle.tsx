export const all_center = {
    display:'flex',
    alignItems :"center",
    justifyContent :"center"
}