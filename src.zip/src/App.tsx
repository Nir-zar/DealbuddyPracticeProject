import "./App.css";
import { store } from "./app/store";
import { Router } from "./route";
import { Provider } from "react-redux";

function App() {
  return(
    <Provider store={store}>
   <Router /> 
   </Provider>
  );
}

export default App;
